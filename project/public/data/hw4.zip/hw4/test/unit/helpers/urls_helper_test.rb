require 'test_helper'

class UrlsHelperTest < ActionView::TestCase
end
