require 'test_helper'

class ShortenizationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
