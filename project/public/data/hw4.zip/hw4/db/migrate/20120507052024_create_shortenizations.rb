class CreateShortenizations < ActiveRecord::Migration
  def change
    create_table :shortenizations do |t|
      t.integer :user_id
      t.integer :url_id

      t.timestamps
    end
  end
end
