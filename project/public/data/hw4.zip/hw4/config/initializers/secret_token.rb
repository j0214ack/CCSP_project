# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Hw4::Application.config.secret_token = 'e6f85ddf3dac863decda4553f1ebd3e20cfcfc267f2b15baa78358946f3d0c8fd969b65ab56bed54c9aa4894f525c37a252ed1801e62faa46e7572b5b063ef3d'
