class Url < ActiveRecord::Base
  attr_accessible :shorten, :url
  validates :url, :uniqueness => true, :presence => true
  validates :shorten, :uniqueness => true, :presence => true
  has_many :shortenizations, :uniq => true
  has_many :users, :through => :shortenizations, :uniq => true
end
