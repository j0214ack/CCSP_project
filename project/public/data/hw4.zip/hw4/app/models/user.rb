class User < ActiveRecord::Base
  attr_accessible :key
  validates :key, :uniqueness => true, :presence => true
  has_many :shortenizations, :uniq => true
  has_many :urls, :through => :shortenizations, :uniq => true
end
