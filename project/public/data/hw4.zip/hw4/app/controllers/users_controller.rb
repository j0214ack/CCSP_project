class UsersController < ApplicationController
  before_filter :check_user, :only => :show
  def show
    if @user == nil
      raise "user is nil!!"
    end
  end

  private
  def check_user
    if cookies[:user_key] != nil
      @user = User.find_by_key cookies[:user_key]
      if @user == nil
        @user = User.create(:key => cookies[:user_key])
        @user.save
      end
    else
      digest = Digest::MD5.hexdigest(Time.now.to_s).encode("utf-8")
      x = 0
      cookies[:user_key] = digest[x..x+7]
      @user = User.find_by_key cookies[:user_key]
      while @user != nil do
        x += 1
        cookies[:user_key] = digest[x..x+7]
        @user = User.find_by_key cookies[:user_key]
      end
      @user = User.create(:key => cookies[:user_key])
      @user.save
    end
  end
end
