class UrlsController < ApplicationController
  before_filter :check_url, :only => :create
  def create
    @user = User.find(params[:user_id])
    @url = @user.urls.build
    @url.url = params[:url][:url]
    x = 0
    digest = Digest::MD5.hexdigest(@url.url).encode("utf-8")
    temp = digest[x..x+7]
    while Url.find_by_shorten(temp) != nil
      x += 1
      temp = digest[x..x+7]
    end
    @url.shorten = temp
    unless @url.save 
      raise @url.errors.full_messages.join
    end
    connect(@user,@url)
    redirect_to '/'
  end
  def show
    @url = Url.find_by_shorten(params[:hashkey])
    if @url == nil
      redirect_to '/'
    else
      link = @url.url
      if /^(http:\/\/|https:\/\/).*/.match(link) == nil
        link = "http://" + link
      end
      redirect_to link
    end
  end

  private
  def check_url
    if params[:url][:url] == ""
      redirect_to '/'
    end
    @user = User.find(params[:user_id])
    @url = Url.find_by_url(params[:url][:url])
    if @url != nil #url already exists in Url table
      if @user.urls.find_by_id(@url) == nil #not connected with current user
        connect(@user,@url)
      end
      @url.updated_at = Time.now
      @url.save
# what happen if new user request old url?
      redirect_to '/'
    end
  end
  def connect(user,url)
    sh = Shortenization.create
    sh.user = user
    sh.url = url
    sh.save
  end
end
